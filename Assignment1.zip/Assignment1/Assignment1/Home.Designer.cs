﻿
namespace Assignment1
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.add_new_button1 = new System.Windows.Forms.Button();
            this.homeDataGridView1 = new System.Windows.Forms.DataGridView();
            this.Col_1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.homeDataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // add_new_button1
            // 
            this.add_new_button1.Location = new System.Drawing.Point(34, 22);
            this.add_new_button1.Name = "add_new_button1";
            this.add_new_button1.Size = new System.Drawing.Size(107, 26);
            this.add_new_button1.TabIndex = 0;
            this.add_new_button1.Text = "Add New";
            this.add_new_button1.UseVisualStyleBackColor = true;
            this.add_new_button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // homeDataGridView1
            // 
            this.homeDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.homeDataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Col_1,
            this.Col_2,
            this.Col_3,
            this.Col_4,
            this.Col_5,
            this.Col_6,
            this.Col_7});
            this.homeDataGridView1.Location = new System.Drawing.Point(30, 76);
            this.homeDataGridView1.Name = "homeDataGridView1";
            this.homeDataGridView1.Size = new System.Drawing.Size(743, 383);
            this.homeDataGridView1.TabIndex = 1;
            // 
            // Col_1
            // 
            this.Col_1.HeaderText = "Col 1";
            this.Col_1.Name = "Col_1";
            // 
            // Col_2
            // 
            this.Col_2.HeaderText = "Col 2";
            this.Col_2.Name = "Col_2";
            // 
            // Col_3
            // 
            this.Col_3.HeaderText = "Col 3";
            this.Col_3.Name = "Col_3";
            // 
            // Col_4
            // 
            this.Col_4.HeaderText = "Col 4";
            this.Col_4.Name = "Col_4";
            // 
            // Col_5
            // 
            this.Col_5.HeaderText = "Col 5";
            this.Col_5.Name = "Col_5";
            // 
            // Col_6
            // 
            this.Col_6.HeaderText = "Col 6";
            this.Col_6.Name = "Col_6";
            // 
            // Col_7
            // 
            this.Col_7.HeaderText = "Col 7";
            this.Col_7.Name = "Col_7";
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(816, 517);
            this.Controls.Add(this.homeDataGridView1);
            this.Controls.Add(this.add_new_button1);
            this.Name = "Home";
            this.Text = "Home";
            ((System.ComponentModel.ISupportInitialize)(this.homeDataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button add_new_button1;
        private System.Windows.Forms.DataGridView homeDataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_7;
    }
}