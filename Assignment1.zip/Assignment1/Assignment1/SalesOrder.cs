﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment1
{
    public partial class SalesOrder : Form
    {
        public SalesOrder()
        {
            InitializeComponent();
            dataGridView1.CellValueChanged += new DataGridViewCellEventHandler(dataGridView1_CellValueChanged);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void SalesOrder_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'demo2016DataSet.StkItem' table. You can move, or remove it, as needed.
            this.stkItemTableAdapter.Fill(this.demo2016DataSet.StkItem);
            // TODO: This line of code loads data into the 'demo2016DataSet.Client' table. You can move, or remove it, as needed.
            this.clientTableAdapter.Fill(this.demo2016DataSet.Client);

        }
         
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void CutomerName_SelectedIndexChanged(object sender, EventArgs e)
        {
             


        }

        private void CutomerName_Click(object sender, EventArgs e)
        {
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Test");
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView dataGridView = sender as DataGridView;
            if (dataGridView == null || e.RowIndex < 0) return;

            
            if (e.ColumnIndex == dataGridView1.Columns["Item_Code"].Index)
            {
                // Defining itemcode to fetch Price and desc
                var itemCode = dataGridView.Rows[e.RowIndex].Cells["Item_Code"].Value?.ToString();

                
                var description = GetDescriptionByItemCode(itemCode); // function getting desc
                var price = GetPriceByItemCode(itemCode); // function getting price

                //setting desc and price values to appropriate datagridview column
                dataGridView.Rows[e.RowIndex].Cells["Description"].Value = description;
                dataGridView.Rows[e.RowIndex].Cells["Price"].Value = price;
            }

            
            if (e.ColumnIndex == dataGridView1.Columns["Quantity"].Index)
            {
                
                if (!int.TryParse(dataGridView.Rows[e.RowIndex].Cells["Quantity"].Value?.ToString(), out int quantity))
                {
                    quantity = 0; 
                }

                
                if (!decimal.TryParse(dataGridView.Rows[e.RowIndex].Cells["Price"].Value?.ToString(), out decimal price))
                {
                    price = 0; 
                }

                
                decimal totalPrice = quantity * price;

                
                dataGridView.Rows[e.RowIndex].Cells["Excl_Amount"].Value = totalPrice;
            }
        }


        private string GetDescriptionByItemCode(string itemCode)
        {
            // Search the stkItemBindingSource for the description corresponding to the item code
            foreach (DataRowView row in stkItemBindingSource)
            {
                if (row["Code"].ToString() == itemCode)
                {
                    return row["Description_1"].ToString(); 
                }
            }

            return "Description Not Found"; // Return this if the description is not found
        }

        private string GetPriceByItemCode(string itemcode)
        { 
        
            foreach(DataRowView row in stkItemBindingSource)
            {
                if(row["Code"].ToString() == itemcode)
                {
                    return row["AveUCst"].ToString();
                }
            }
            return "0";
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
