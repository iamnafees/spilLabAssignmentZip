﻿namespace Assignment1
{
    internal class MySqlConnection
    {
        private object connectionString;

        public MySqlConnection(object connectionString)
        {
            this.connectionString = connectionString;
        }
    }
}